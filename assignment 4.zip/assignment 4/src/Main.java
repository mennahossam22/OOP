import java.util.ArrayList;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args)
    {
        //q2 runtime expetion
        //q3
        /*ArrayList<Integer> a=new ArrayList<>(5);
        a.add(20);
        a.add(10);
        a.add(9);
        a.add(12);
        a.add(30);
        int max =0;
        for(int j=0;j<=5;j++)
        {
            for(int i=0;i<=5;i++)
            {

                if (a.get(j)>a.get(i+1))
                {
                    max=a.get(j);
                }
                else
                    max=a.get(i+1);
            }
            System.out.println(max);
        }*/
        //q5
        String fileName = new Scanner(System.in).next();
        File file = new File("src/" + fileName);
        int lineNum = 0;
        int wordCount = 0;

        try {
            Scanner input = new Scanner(file);
            while (input.hasNextLine()) {
                String line = input.nextLine();
                lineNum++;
                String[] words = line.split((" "));
                wordCount += words.length;
            }
            input.close();

            System.out.println(lineNum);
            System.out.println(wordCount);

        }
        catch (FileNotFoundException e){
            System.out.println("File Not Found");
        }



    }
}